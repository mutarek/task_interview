import 'package:test_application/core/app_export.dart';

class ApiClient extends GetConnect {}
