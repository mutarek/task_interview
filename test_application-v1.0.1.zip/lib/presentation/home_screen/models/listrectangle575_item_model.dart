class Listrectangle575ItemModel {}
