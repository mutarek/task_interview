class ElectronicsItemModel {}
