class SliderfooddeliveryItemModel {}
