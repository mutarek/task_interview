class Gridrectangle575ItemModel {}
