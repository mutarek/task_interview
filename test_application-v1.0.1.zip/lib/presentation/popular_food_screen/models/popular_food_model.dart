import 'package:get/get.dart';
import 'gridrectangle575_item_model.dart';

class PopularFoodModel {
  RxList<Gridrectangle575ItemModel> gridrectangle575ItemList =
      RxList.filled(5, Gridrectangle575ItemModel());
}
