class ImageConstant {
  static String imgRectangle584 = 'assets/images/img_rectangle584.png';

  static String imgGrid = 'assets/images/img_grid.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgImage111 = 'assets/images/img_image111.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgShape = 'assets/images/img_shape.png';

  static String imgRectangle575 = 'assets/images/img_rectangle575.png';

  static String imgScreenshot202 = 'assets/images/img_screenshot202.png';

  static String imgBg = 'assets/images/img_bg.png';

  static String imgRectangle5756 = 'assets/images/img_rectangle575_6.png';

  static String imgSettings16X18 = 'assets/images/img_settings_16X18.svg';

  static String imgVector1 = 'assets/images/img_vector1.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgImage113 = 'assets/images/img_image113.png';

  static String imgVector142X222 = 'assets/images/img_vector_142X222.png';

  static String imgRectangle577 = 'assets/images/img_rectangle577.png';

  static String imgFavorite1 = 'assets/images/img_favorite_1.svg';

  static String imgImage110 = 'assets/images/img_image110.png';

  static String imgEllipse1388 = 'assets/images/img_ellipse1388.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgImage109 = 'assets/images/img_image109.png';

  static String imgRectangle5758 = 'assets/images/img_rectangle575_8.png';

  static String imgGroup5135 = 'assets/images/img_group5135.svg';

  static String imgRectangle575120X158 =
      'assets/images/img_rectangle575_120X158.png';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgRectangle5754 = 'assets/images/img_rectangle575_4.png';

  static String imgImage112 = 'assets/images/img_image112.png';

  static String imgRectangle5759 = 'assets/images/img_rectangle575_9.png';

  static String imgPngkey1 = 'assets/images/img_pngkey1.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgImage108 = 'assets/images/img_image108.png';

  static String imgRectangle57599X81 =
      'assets/images/img_rectangle575_99X81.png';

  static String imgRectangle5757 = 'assets/images/img_rectangle575_7.png';

  static String imgFavorite27X27 = 'assets/images/img_favorite_27X27.svg';

  static String imgRectangle5755 = 'assets/images/img_rectangle575_5.png';

  static String imgRectangle575120X178 =
      'assets/images/img_rectangle575_120X178.png';

  static String imgRectangle5751 = 'assets/images/img_rectangle575_1.png';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgRectangle5753 = 'assets/images/img_rectangle575_3.png';

  static String imgCart = 'assets/images/img_cart.svg';

  static String imgImage114 = 'assets/images/img_image114.png';

  static String imgChemdelachem = 'assets/images/img_chemdelachem.png';

  static String imgGridWhiteA700 = 'assets/images/img_grid_white_A700.png';

  static String imgSettings22X22 = 'assets/images/img_settings_22X22.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgRectangle5752 = 'assets/images/img_rectangle575_2.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
